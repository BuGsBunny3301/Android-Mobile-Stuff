package com.example.bug.adammawlafinalexam;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

public class Workout extends AppCompatActivity {

    private WebView webView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        webView = findViewById(R.id.webView);

        WebSettings webSettings = webView.getSettings();
        webSettings.setJavaScriptEnabled(true);

        webView.loadUrl("http://www.womenshealthmag.com/fitness/a19938894/six-week-weight-loss-plan-week-6/");
        webView.setWebViewClient(new WebViewClient());
    }

    @Override
    public void onBackPressed() {

        if(webView.canGoBack() == true) {
            webView.goBack();
        }
        else {
            super.onBackPressed();
        }

    }

}
