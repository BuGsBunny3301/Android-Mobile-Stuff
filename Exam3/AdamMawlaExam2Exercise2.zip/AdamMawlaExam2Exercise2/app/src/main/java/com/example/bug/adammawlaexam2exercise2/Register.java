package com.example.bug.adammawlaexam2exercise2;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class Register extends AppCompatActivity {

    EditText name, email, password, confirmPassword;
    Button register;
    DatabaseHelper db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        name = findViewById(R.id.name);
        email = findViewById(R.id.email);
        password = findViewById(R.id.password);
        confirmPassword = findViewById(R.id.confirmpass);
        register = findViewById(R.id.button);

        db = new DatabaseHelper(this);

        register.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(password.getText().toString().equals(confirmPassword.getText().toString())){
                    AddData(name.getText().toString(), email.getText().toString(), password.getText().toString());
                }else{
                    Toast.makeText(Register.this, "Passwords don't match", Toast.LENGTH_SHORT).show();
                }
                
            }
        });


    }
    public void AddData(String item1, String item2, String item3) {
        boolean insertData = db.AddData(item1, item2, item3);

        if(insertData == true) {
            Toast.makeText(this, "YOU ENTERED DATA SUCCESSFULLY!", Toast.LENGTH_LONG).show();

        }else {
            Toast.makeText(this, "SOMETHING WENT WRONG!", Toast.LENGTH_LONG).show();
        }
    }
    
}
