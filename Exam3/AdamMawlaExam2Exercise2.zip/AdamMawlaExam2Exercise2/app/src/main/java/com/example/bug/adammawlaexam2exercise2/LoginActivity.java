package com.example.bug.adammawlaexam2exercise2;

import android.content.Intent;
import android.database.Cursor;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class LoginActivity extends AppCompatActivity {

    EditText username, password;
    Button register;

    DatabaseHelper db;
    Cursor data;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        username = findViewById(R.id.username);
        password = findViewById(R.id.password);
        register = findViewById(R.id.register);

        db = new DatabaseHelper(this);

        data = db.getListContents();

        register.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                getData();
            }
        });
    }

    public void getData(){
        if (data.getCount() == 0) {
            Toast.makeText(LoginActivity.this, "DATABASE IS EMPTY!", Toast.LENGTH_LONG).show();
        } else {
            while (data.moveToNext()) {

                if (username.getText().toString().equals(data.getString(1))
                        && password.getText().toString().equals(data.getString(2))) {
                    Intent intent = new Intent(getBaseContext(), Friends.class);
                    startActivity(intent);
                } else {
                    Intent intent = new Intent(getBaseContext(), Register.class);
                    startActivity(intent);
                }


            }

        }
    }
}