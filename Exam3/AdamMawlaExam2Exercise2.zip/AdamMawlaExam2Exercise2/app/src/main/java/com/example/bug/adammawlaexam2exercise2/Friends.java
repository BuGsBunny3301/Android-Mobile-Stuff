package com.example.bug.adammawlaexam2exercise2;

import android.database.Cursor;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;

public class Friends extends AppCompatActivity {

    ListView listView;
    ArrayAdapter<String> arrayAdapter;
    ArrayList<String> arrayList;
    DatabaseHelper db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_friends);

        listView = findViewById(R.id.listView);
        db = new DatabaseHelper(this);
        arrayList = new ArrayList<>();
        Cursor data = db.getListContents();

        if(data.getCount() == 0) {
            Toast.makeText(this, "DATABASE IS EMPTY!", Toast.LENGTH_LONG).show();
        }else {
            while(data.moveToNext()) {

                arrayList.add(data.getString(1)); //1 is column reference (item)
                arrayAdapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, arrayList);
                listView.setAdapter(arrayAdapter);
            }
        }



    }


}
