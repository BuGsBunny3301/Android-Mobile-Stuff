package com.example.bug.adammawlaexam3;

import android.content.Intent;
import android.content.SharedPreferences;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class InputActivity extends AppCompatActivity {

    EditText editText1, editText2;
    Button go;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        editText1 = findViewById(R.id.editText1);
        editText2 = findViewById(R.id.editText2);

        go = findViewById(R.id.button);

        editText1.setText(getText1());
        editText2.setText(getText2());

        go.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getBaseContext(), AnimationActivity.class);
                setText();
                startActivity(intent);
            }
        });
    }

    private void setText(){
        SharedPreferences sharedPrefs = getSharedPreferences("text", MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPrefs.edit();
        editor.putString("editText1", editText1.getText().toString());
        editor.putString("editText2", editText2.getText().toString());
        editor.apply();
    }

    private String getText1() {
        SharedPreferences sharedPrefs = getSharedPreferences("text", MODE_PRIVATE);
//        return sharedPrefs.getInt("color", getResources().getColor(R.color.colorPrimary));
        return sharedPrefs.getString("editText1", editText1.getText().toString());
    }

    private String getText2(){
        SharedPreferences sharedPrefs = getSharedPreferences("text", MODE_PRIVATE);
//        return sharedPrefs.getInt("color", getResources().getColor(R.color.colorPrimary));
        return sharedPrefs.getString("editText2", editText2.getText().toString());
    }
}
