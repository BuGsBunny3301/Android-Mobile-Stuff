package com.example.bug.easterhomework;

import android.app.Fragment;
import android.content.Intent;
import android.content.res.Configuration;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

/**
 * Created by bug on 4/10/18.
 */

public class DisplayInfoFragment extends Fragment {

    private ViewGroup container;
    private LayoutInflater inflater;
    private TextView name, email, home, phone, message;
    private ImageView imageView;

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, Bundle savedInstanceState) {
        this.container = container;
        this.inflater = inflater;

        return initializeUserInterface();
    }

    @Override
    public void onConfigurationChanged(Configuration newConfig) {

        String nameText = name.getText().toString(),
                emailText = email.getText().toString(),
                homeText = home.getText().toString(),
                phoneText = phone.getText().toString(),
                messageText = message.getText().toString();

        View view = initializeUserInterface();

        name.setText(nameText);
        email.setText(emailText);
        home.setText(homeText);
        phone.setText(phoneText);
        message.setText(messageText);

        imageView.setImageURI(ImageManager.selectedImageUri);

        container.addView(view);

        super.onConfigurationChanged(newConfig);
    }

    public View initializeUserInterface() {
        View view;

        if(container != null)
            container.removeAllViews();

        int orientation = getActivity().getResources().getConfiguration().orientation;

        if(orientation == Configuration.ORIENTATION_PORTRAIT)
            view = inflater.inflate(R.layout.fragment_vertical_info, container, false);
        else
            view = inflater.inflate(R.layout.fragment_horizantal_info, container, false);

        name = view.findViewById(R.id.nameText);
        email = view.findViewById(R.id.emailText);
        home = view.findViewById(R.id.homeText);
        phone = view.findViewById(R.id.phoneText);
        message = view.findViewById(R.id.messageText);

        imageView = view.findViewById(R.id.imageView);


        name.setText(Info.allInfo.get(0));
        email.setText(Info.allInfo.get(1));
        home.setText(Info.allInfo.get(2));
        phone.setText(Info.allInfo.get(3));
        message.setText(Info.allInfo.get(4));

        imageView.setImageURI(ImageManager.selectedImageUri);

            return view;
    }
}
