package com.example.bug.easterhomework;

import android.app.Fragment;
import android.app.FragmentManager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.FrameLayout;

public class DisplayInfo extends AppCompatActivity {

    private FrameLayout frameLayout;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_display_info);

        frameLayout = findViewById(R.id.framelayout);

        getFragmentManager().beginTransaction().replace(R.id.framelayout, new DisplayInfoFragment())
                .commit();
    }

    public void loadFragment(Fragment fragment) {
        frameLayout.removeAllViews();

        getFragmentManager().beginTransaction()
                .addToBackStack(null)
                .replace(R.id.framelayout, fragment)
                .commit();
    }

    @Override
    public void onBackPressed() {

        if(frameLayout != null) {
            frameLayout.removeAllViews();
        }

        FragmentManager fragmentManager = getFragmentManager();
        if(fragmentManager.getBackStackEntryCount() > 1) {
            fragmentManager.popBackStack();
            return;
        }

        super.onBackPressed();
    }
}
