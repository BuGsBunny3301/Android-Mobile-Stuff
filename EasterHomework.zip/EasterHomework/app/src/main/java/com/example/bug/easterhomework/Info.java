package com.example.bug.easterhomework;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.support.annotation.Nullable;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;

import java.util.ArrayList;

public class Info extends Fragment {

    View view;

    @SuppressLint("StaticFieldLeak")
    static EditText name, email, home, phone, message;

    public static ArrayList<String> allInfo;

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {

        view = inflater.inflate(R.layout.fragment_info, container, false);

        name = view.findViewById(R.id.nameText);
        email = view.findViewById(R.id.emailField);
        home = view.findViewById(R.id.homeField);
        phone = view.findViewById(R.id.phoneField);
        message = view.findViewById(R.id.messageField);

        return view;
    }

    public static void fillInfo(){
        allInfo = new ArrayList<>();

        allInfo.add(name.getText().toString());
        allInfo.add(email.getText().toString());
        allInfo.add(home.getText().toString());
        allInfo.add(phone.getText().toString());
        allInfo.add(message.getText().toString());
    }
}
