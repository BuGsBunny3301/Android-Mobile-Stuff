package com.example.bug.adammawlaexam3question2;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class AddStudentActivity extends AppCompatActivity {

    Button addBtn, viewBtn;
    EditText nameField, emailField, phoneField, gradesField;
    DatabaseHelper db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_student);

        db = new DatabaseHelper(this);

        nameField = findViewById(R.id.nameField);
        emailField = findViewById(R.id.emailField);
        phoneField = findViewById(R.id.phoneField);
        gradesField = findViewById(R.id.gradeField);

        addBtn = findViewById(R.id.addBtn);
        viewBtn = findViewById(R.id.viewBtn);

        addBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if(db.AddData(nameField.getText().toString(),
                        emailField.getText().toString(),
                        phoneField.getText().toString(),
                        gradesField.getText().toString())){

                    Toast.makeText(AddStudentActivity.this, "Entry Successfully Added", Toast.LENGTH_SHORT).show();

                }else{
                    Toast.makeText(AddStudentActivity.this, "Something Went Wrong", Toast.LENGTH_SHORT).show();
                }

            }
        });

        viewBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getBaseContext(), ViewStudentsActivity.class);
                startActivity(intent);
            }
        });

    }
}
