package com.example.bug.adammawlaexam3question2;

import android.support.design.widget.AppBarLayout;
import android.support.design.widget.TabLayout;
import android.support.v4.view.ViewPager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class ViewStudentsActivity extends AppCompatActivity {

    private TabLayout tabLayout;
    private AppBarLayout appBarLayout;
    private ViewPager viewPager;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_students);

        tabLayout = findViewById(R.id.tabid);
        appBarLayout = findViewById(R.id.appbarid);
        viewPager = findViewById(R.id.viewpagerid);

        ViewPagerAdapter adapter = new ViewPagerAdapter(getSupportFragmentManager());
        //adding fragments
        adapter.AddFRagment(new Fragment_Emails(), "Emails");
        adapter.AddFRagment(new Fragment_Phones(), "Phones");
        adapter.AddFRagment(new Fragment_Grades(), "Grades");

        //adapter setup
        viewPager.setAdapter(adapter);
        tabLayout.setupWithViewPager(viewPager);

    }
}