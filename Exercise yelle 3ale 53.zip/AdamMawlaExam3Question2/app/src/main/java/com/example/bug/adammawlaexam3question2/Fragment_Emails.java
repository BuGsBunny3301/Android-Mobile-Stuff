package com.example.bug.adammawlaexam3question2;

import android.database.Cursor;
import android.support.v4.app.Fragment;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;

public class Fragment_Emails extends Fragment {

    View view;
    ListView emailList;
    ArrayList<String> arr_emails;

    DatabaseHelper db;

    public Fragment_Emails() {
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, Bundle savedInstanceState) {

        view = inflater.inflate(R.layout.activity_fragment__emails, container, false);

        db = new DatabaseHelper(getActivity());

        emailList = view.findViewById(R.id.listViewPhones);
        arr_emails = new ArrayList<>();

        Cursor data = db.getContents();

        if(data.getCount() == 0) {
            Toast.makeText(getContext(), "DATABASE IS EMPTY!", Toast.LENGTH_LONG).show();
        }else {
            while(data.moveToNext()) {

                arr_emails.add(data.getString(2));
                ArrayAdapter<String> emailsAdapter = new ArrayAdapter<>(getContext(), android.R.layout.simple_list_item_1, arr_emails);
                emailList.setAdapter(emailsAdapter);
            }
        }

        return view;
    }
}
